<template>
  <h2>日志记录页面</h2>
</template>

<script>
export default {

}
</script>

<style>

</style>