<template>
  <h2>Appselect页面</h2>
</template>

<script>
export default {

}
</script>

<style>

</style>